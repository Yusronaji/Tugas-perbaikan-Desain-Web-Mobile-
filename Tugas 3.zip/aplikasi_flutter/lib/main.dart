import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pembelian Tiket Konser',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pembelian Tiket Konser'),
      ),
      body: _buildBody(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.music_note),
            label: 'Konser',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.confirmation_number),
            label: 'Tiket Saya',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    switch (_currentIndex) {
      case 0:
        return ConcertPage();
      case 1:
        return MyTicketsPage();
      case 2:
        return ProfilePage();
      default:
        return Container();
    }
  }
}

class ConcertPage extends StatelessWidget {
  final List<Concert> concerts = [
    Concert('Konser Coldplay', 'Stadion Utama Gelora Bung Karno Jakarta', '15 November 2023', 25),
    Concert('Konser Alan Walker', 'Atlas Beach Club Bali', '5 Desember 2023', 50),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: concerts.length,
      itemBuilder: (context, index) {
        return ConcertCard(concert: concerts[index]);
      },
    );
  }
}

class ConcertCard extends StatelessWidget {
  final Concert concert;

  ConcertCard({required this.concert});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10.0),
      elevation: 2.0,
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              concert.name,
              style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Text('Lokasi: ${concert.location}'),
            Text('Tanggal: ${concert.date}'),
            Text('Jumlah Tiket Tersedia: ${concert.availableTickets}'),
            SizedBox(height: 8.0),
            ElevatedButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('Konfirmasi Pembelian'),
                      content: Text('Anda akan membeli tiket untuk ${concert.name}'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: Text('Batal'),
                        ),
                        TextButton(
                          onPressed: () {
                        
                            Navigator.of(context).pop();
                          },
                          child: Text('Beli'),
                        ),
                      ],
                    );
                  },
                );
              },
              child: Text('Beli Tiket'),
            ),
          ],
        ),
      ),
    );
  }
}

class MyTicketsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Tiket Saya',
        style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Profil Pengguna',
        style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class Concert {
  final String name;
  final String location;
  final String date;
  final int availableTickets;

  Concert(this.name, this.location, this.date, this.availableTickets);
}
